package com.pras.ujidana;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Layanan Aksesibilitas UJI v3. Hanya MEMBACA layar dan mengetuk menu Riwayat / satu transaksi /
 * tombol refresh. Tidak pernah mengetik PIN/password dan tidak menekan tombol bayar / transfer.
 */
public class BacaService extends AccessibilityService {

    static BacaService aktif;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView tombol;
    private int manualKe = 0;

    private boolean berjalan = false;
    private String paket = "";
    private String nama = "";
    private boolean goPay = false;
    private boolean ovo = false;
    private boolean namaDiDaftar = false;   // GoPay & OVO: nama tampil di daftar
    
    private static final Pattern P_NOMINAL = Pattern.compile("-?\\s?Rp\\s?[\\d.]+");
    private static final Pattern P_JAM = Pattern.compile("\\b\\d{1,2}[:.]\\d{2}\\b");
    private static final Pattern P_TGL = Pattern.compile("\\d{1,2}\\s+\\w+\\s+20\\d{2}");

    // ───────────────────────── siklus layanan ─────────────────────────

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        aktif = this;
        Hasil.tulis(this, "✓ Layanan Aksesibilitas tersambung");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(Intent intent) { sembunyikanTombol(); aktif = null; return super.onUnbind(intent); }
    @Override public void onDestroy() { sembunyikanTombol(); aktif = null; super.onDestroy(); }

    void tulis(String s) { Hasil.tulis(this, s); }

    // ───────────────────────── uji otomatis ─────────────────────────

    void mulaiUji(String paketApp, String namaApp) {
        if (berjalan) { tulis("⚠ Uji sebelumnya masih berjalan, tunggu sampai selesai"); return; }
        berjalan = true;
        paket = paketApp;
        nama = namaApp;
        goPay = paketApp.contains("gopay");
        ovo = paketApp.equals("ovo.id") || paketApp.contains("ovo");
        namaDiDaftar = goPay || ovo;

        String versiUji = "?";
        try { versiUji = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        tulis("════════ UJI " + nama + " (aplikasi uji v" + versiUji + ") ════════");
        tulis("HP: " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE);
        try {
            tulis(nama + " versi " + getPackageManager().getPackageInfo(paket, 0).versionName);
        } catch (Exception e) {
            tulis("✗ " + nama + " tidak terpasang"); selesai(); return;
        }
        if (!bukaApp()) { selesai(); return; }
        tulis("… membuka " + nama);
        tungguTerbuka(0);
    }

    private boolean bukaApp() {
        Intent i = getPackageManager().getLaunchIntentForPackage(paket);
        if (i == null) { tulis("✗ " + nama + " tidak bisa dibuka"); return false; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); return true; }
        catch (Exception e) { tulis("✗ Gagal membuka " + nama + ": " + e.getMessage()); return false; }
    }

    private String paketAktif() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        return (r == null || r.getPackageName() == null) ? "" : r.getPackageName().toString();
    }

    private void tungguTerbuka(final int coba) {
        if (paket.equals(paketAktif())) {
            tulis("✓ " + nama + " terbuka");
            if (ovo) { 
                tulis("… Mendeteksi halaman PIN OVO…"); 
                tungguUnlockOVO(0); 
                return; 
            }
            h.postDelayed(new Runnable() { @Override public void run() { bukaMenu(); } }, 3500);
            return;
        }
        if (coba >= 20) { tulis("✗ " + nama + " tidak terbuka dalam 20 detik"); selesai(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguTerbuka(coba + 1); } }, 1000);
    }

    /** OVO meminta autentikasi: pengguna memasukkan PIN sendiri, layanan hanya menunggu beranda. */
    private void tungguUnlockOVO(final int coba) {
        boolean beranda = false;
        boolean diHalamanPIN = false;
        
        List<String> teksLayar = teksUrut();
        for (String t : teksLayar) {
            String l = t.toLowerCase(Locale.ROOT);
            // Cek apakah sudah masuk beranda
            if (l.contains("ovo cash") || l.contains("total saldo") || l.equals("history") || l.contains("tarik tunai")) { 
                beranda = true; 
                break; 
            }
            // Cek apakah sedang di halaman input PIN
            if (l.contains("masukkan pin") || l.contains("enter pin") || l.contains("pin kamu") || l.contains("verifikasi") || l.contains("security")) {
                diHalamanPIN = true;
            }
        }

        // Jika layar sangat sedikit teksnya (biasanya halaman PIN hanya ada judul dan titik-titik), anggap sebagai halaman PIN
        if (!beranda && teksLayar.size() < 10 && coba < 5) {
             diHalamanPIN = true;
        }

        if (beranda) { 
            tulis("✓ OVO terbuka (PIN sudah dimasukkan/terlewat)"); 
            bukaMenu(); 
            return; 
        }

        // Halaman PIN terdeteksi: minta pengguna membuka OVO secara manual.
        // Layanan tidak membaca, menyimpan, atau mengetik PIN.
        if (diHalamanPIN && coba == 0) {
            tulis("→ Halaman PIN OVO terdeteksi. Silakan masukkan PIN secara manual.");
            tulis("→ Layanan akan melanjutkan otomatis setelah beranda OVO terdeteksi.");
        }

        if (coba >= 90) { 
            tulis("✗ OVO belum terbuka / PIN gagal dimasukkan dalam 90 dtk"); 
            selesai(); 
            return; 
        }
        h.postDelayed(new Runnable() { @Override public void run() { tungguUnlockOVO(coba + 1); } }, 1000);
    }

    private void bukaMenu() {
        AccessibilityNodeInfo menu = cariTeks(ovo
                ? new String[]{"history", "riwayat"}
                : goPay
                ? new String[]{"riwayat"}
                : new String[]{"aktivitas", "activity", "riwayat", "history"});
        if (menu == null) {
            tulis("✗ Menu riwayat tidak ketemu. Pakai tombol 📸 manual.");
            kembali(); return;
        }
        tulis("→ Buka menu: \"" + teksNode(menu) + "\"");
        klik(menu);
        tungguDaftar(0);
    }

    private void tungguDaftar(final int coba) {
        if (daftarSiap()) {
            tulis("✓ Daftar transaksi muncul (±" + (coba + 1) + " dtk)");
            h.postDelayed(new Runnable() { @Override public void run() { tampilkanDaftar("DAFTAR AWAL"); } }, 800);
            return;
        }
        if (coba >= 15) { tulis("⚠ Daftar belum muncul 15 dtk"); ringkas("DAFTAR (mungkin belum siap)"); kembali(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDaftar(coba + 1); } }, 1000);
    }

    private void tampilkanDaftar(String judul) {
        ringkas(judul);
        mulaiKoleksi();
    }

    /** Apakah teks ini satu baris transaksi MASUK? */
    private boolean teksMasuk(String low) {
        if (ovo) return low.startsWith("transfer dari");
        if (goPay) return low.startsWith("diterima dari");
        return low.startsWith("terima uang") || low.startsWith("receive money");
    }

    private boolean daftarSiap() {
        for (String t : teksUrut()) {
            String l = t.toLowerCase(Locale.ROOT);
            if (ovo) {
                if (l.startsWith("transfer dari") || l.startsWith("transfer ke") || l.equals("history")) return true;
            } else if (goPay) {
                if (l.startsWith("diterima dari") || l.startsWith("ditransfer ke") || l.equals("riwayat transaksi")) return true;
            } else {
                if (l.startsWith("terima uang") || l.startsWith("kirim ke") || l.equals("bulan ini")
                        || l.startsWith("receive money") || l.startsWith("send to") || l.equals("this month")) return true;
            }
        }
        return false;
    }

    // ───────────────────────── uji refresh ─────────────────────────

    private void mulaiRefresh() {
        tulis("──── UJI REFRESH ────");
        if (goPay) {
            tulis("GoPay cara: gulir ke bawah");
            refreshGulir();
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah GULIR");
                lanjutKeDetail();
            } }, 2500);
        } else {
            refreshDana1();
        }
    }

    // DANA cara 1: gulir ke bawah
    private void refreshDana1() {
        tulis("DANA cara 1: gulir ke bawah");
        refreshGulir();
        h.postDelayed(new Runnable() { @Override public void run() {
            ringkas("Setelah cara 1 (GULIR)");
            refreshDana2();
        } }, 2500);
    }

    // DANA cara 2: tekan kembali lalu masuk Aktivitas lagi
    private void refreshDana2() {
        tulis("DANA cara 2: kembali lalu masuk Aktivitas lagi");
        performGlobalAction(GLOBAL_ACTION_BACK);
        h.postDelayed(new Runnable() { @Override public void run() {
            AccessibilityNodeInfo menu = cariTeks(new String[]{"aktivitas", "activity", "riwayat", "history"});
            if (menu == null) { tulis("  ⚠ tombol Aktivitas tidak ketemu setelah kembali"); refreshDana3(); return; }
            klik(menu);
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah cara 2 (BACK + masuk lagi)");
                refreshDana3();
            } }, 4000);
        } }, 2500);
    }

    // DANA cara 3: force close DANA lalu buka lagi
    private void refreshDana3() {
        tulis("DANA cara 3: force close lalu buka lagi");
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + paket));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { tulis("  ✗ tidak bisa buka Info aplikasi: " + e.getMessage()); lanjutKeDetail(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tekanPaksaBerhenti(0); } }, 2500);
    }

    private void tekanPaksaBerhenti(final int coba) {
        AccessibilityNodeInfo b = cariTeksMengandung(new String[]{"paksa berhenti", "berhenti paksa", "force stop", "paksa henti"});
        if (b != null) {
            tulis("  → tekan \"" + teksNode(b) + "\" (" + klik(b) + ")");
            h.postDelayed(new Runnable() { @Override public void run() { konfirmasiPaksa(0); } }, 1500);
            return;
        }
        if (coba >= 6) { tulis("  ⚠ tombol Paksa Berhenti tidak ketemu — lewati, buka DANA lagi"); bukaUlangDana(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tekanPaksaBerhenti(coba + 1); } }, 1000);
    }

    private void konfirmasiPaksa(final int coba) {
        // Dialog konfirmasi: tombol "OK" / "Oke" / "Paksa Berhenti"
        for (AccessibilityNodeInfo n : semuaNode()) {
            String t = teksNode(n).toLowerCase(Locale.ROOT);
            if (t.equals("ok") || t.equals("oke") || t.equals("paksa berhenti") || t.equals("force stop")) {
                tulis("  → konfirmasi \"" + teksNode(n) + "\" (" + klik(n) + ")");
                h.postDelayed(new Runnable() { @Override public void run() { bukaUlangDana(); } }, 1500);
                return;
            }
        }
        if (coba >= 4) { tulis("  (tidak ada dialog konfirmasi / sudah berhenti)"); bukaUlangDana(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { konfirmasiPaksa(coba + 1); } }, 800);
    }

    private void bukaUlangDana() {
        performGlobalAction(GLOBAL_ACTION_HOME);
        h.postDelayed(new Runnable() { @Override public void run() {
            bukaApp();
            h.postDelayed(new Runnable() { @Override public void run() { tungguTerbukaLagi(0); } }, 3500);
        } }, 1500);
    }

    private void tungguTerbukaLagi(final int coba) {
        if (paket.equals(paketAktif())) {
            AccessibilityNodeInfo menu = cariTeks(new String[]{"aktivitas", "activity", "riwayat", "history"});
            if (menu != null) klik(menu);
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkas("Setelah cara 3 (FORCE CLOSE + buka lagi)");
                lanjutKeDetail();
            } }, 4500);
            return;
        }
        if (coba >= 15) { tulis("  ⚠ DANA tidak terbuka lagi dalam 15 dtk"); lanjutKeDetail(); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguTerbukaLagi(coba + 1); } }, 1000);
    }

    // ───────────────────────── uji baca detail ─────────────────────────

    private void lanjutKeDetail() {
        tulis("──── UJI BACA DETAIL (1 transaksi) ────");
        AccessibilityNodeInfo baris = cariBarisMasuk();
        if (baris == null) {
            tulis("✗ Tidak ketemu baris transaksi MASUK yang terlihat. Pakai 📸 manual untuk cek detail.");
            kembali(); return;
        }
        tulis("→ Ketuk transaksi: \"" + teksNode(baris) + "\"");
        ketukBaris(baris);
        h.postDelayed(new Runnable() { @Override public void run() { tungguDetail(0, false); } }, 2500);
    }

    /** Ketuk satu baris transaksi. GoPay: klik node. DANA (web): ketuk tengah baris. */
    private void ketukBaris(AccessibilityNodeInfo n) {
        if (namaDiDaftar) { tulis("  (" + klik(n) + ")"); return; }   // GoPay & OVO: baris bisa diklik
        Rect b = new Rect(); n.getBoundsInScreen(b);
        int x = (int) (getResources().getDisplayMetrics().widthPixels * 0.45f);
        tulis("  (ketuk tengah baris " + x + "," + b.centerY() + ")");
        ketuk(x, b.centerY());
    }

    /** Tunggu halaman detail benar-benar terbuka (kadang ada popup/event yang lambat). */
    private void tungguDetail(final int coba, final boolean sudahUlang) {
        if (detailSiap()) {
            tulis("✓ Halaman detail terbuka (±" + (coba + 2) + " dtk)");
            ringkasDetail("DETAIL (sebelum digulir)");   // nama DANA ada di atas
            geser(true);                                  // jam GoPay ada di bawah
            h.postDelayed(new Runnable() { @Override public void run() {
                ringkasDetail("DETAIL (setelah digulir)");
                tulis("→ kembali");
                performGlobalAction(GLOBAL_ACTION_BACK);
                h.postDelayed(new Runnable() { @Override public void run() { kembali(); } }, 1500);
            } }, 2000);
            return;
        }
        // DANA: kalau 4 dtk belum terbuka, ketuk ulang barisnya sekali
        if (!goPay && coba == 4 && !sudahUlang) {
            AccessibilityNodeInfo r = cariBarisMasuk();
            if (r != null) { tulis("… detail belum terbuka, ketuk ulang baris"); ketukBaris(r); }
            h.postDelayed(new Runnable() { @Override public void run() { tungguDetail(coba + 1, true); } }, 1500);
            return;
        }
        if (coba >= 12) {
            tulis("⚠ Detail tidak terbuka dalam 14 dtk — mungkin ada popup/event yang menutupi");
            ringkasDetail("LAYAR SAAT GAGAL");
            performGlobalAction(GLOBAL_ACTION_BACK);
            h.postDelayed(new Runnable() { @Override public void run() { kembali(); } }, 1500);
            return;
        }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDetail(coba + 1, sudahUlang); } }, 1000);
    }

    /** Ciri halaman detail transaksi (bukan daftar lagi). */
    private boolean detailSiap() {
        for (String t : teksUrut()) {
            String l = t.toLowerCase(Locale.ROOT);
            if (l.contains("rincian transaksi") || l.contains("id transaksi") || l.contains("id dana")
                    || l.contains("detail transaksi") || l.startsWith("terima transfer")
                    || l.contains("transaction detail") || l.contains("transaction id") || l.startsWith("received transfer")) return true;
        }
        return false;
    }

    private void kembali() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        } catch (Exception ignored) { }
        selesai();
    }

    private void selesai() { berjalan = false; tulis("════════ SELESAI ════════"); }

    // ───────────────────────── AMBIL BANYAK SAMPEL ─────────────────────────

    private static class Baris {
        String key, label; int tapY; AccessibilityNodeInfo node;
        Baris(String k, String l, int y, AccessibilityNodeInfo n) { key = k; label = l; tapY = y; node = n; }
    }

    private final List<String> hasilSampel = new ArrayList<>();
    private final java.util.HashSet<String> sudahProses = new java.util.HashSet<>();
    private String lastJam;   // DANA: proses menurun dari jam terbesar → mencegah loncat ke atas
    private int targetSampel;
    private int gulirKosong;
    private Baris barisAktif;   // baris yang sedang dibuka detailnya

    private void mulaiKoleksi() {
        hasilSampel.clear();
        sudahProses.clear();
        lastJam = "99:99";
        gulirKosong = 0;
        targetSampel = 15;
        tulis("──── AMBIL BANYAK SAMPEL (target " + targetSampel + ", buka detail tiap transaksi masuk) ────");
        langkahKoleksi();
    }

    private void langkahKoleksi() {
        if (hasilSampel.size() >= targetSampel) { selesaiKoleksi("tercapai " + targetSampel); return; }
        List<Baris> rows = kumpulBaris();
        Baris next = null;
        if (namaDiDaftar) {
            for (Baris b : rows) if (!sudahProses.contains(b.key)) { next = b; break; }
        } else {
            // DANA: pilih jam TERBESAR yang masih lebih kecil dari jam terakhir (urut menurun)
            for (Baris b : rows) {
                if (b.key.compareTo(lastJam) >= 0) continue;
                if (next == null || b.key.compareTo(next.key) > 0) next = b;
            }
        }
        if (next != null) {
            gulirKosong = 0;
            final Baris nn = next;
            barisAktif = nn;
            detailPertama = null;   // reset data detail untuk transaksi baru
            if (namaDiDaftar) sudahProses.add(nn.key); else lastJam = nn.key;
            tulis("→ #" + (hasilSampel.size() + 1) + " ketuk: " + nn.label);
            ketukBaris(nn.node);
            h.postDelayed(new Runnable() { @Override public void run() { tungguDetailSampel(0, nn, false); } }, 2500);
            return;
        }
        // tidak ada yang cocok terlihat → gulir untuk cari lagi
        gulirKosong++;
        if (gulirKosong > 3) { selesaiKoleksi("sudah mentok / tidak ada transaksi baru"); return; }
        tulis("… gulir ke bawah untuk transaksi berikutnya");
        geser(true);
        h.postDelayed(new Runnable() { @Override public void run() { langkahKoleksi(); } }, 2000);
    }

    private void tungguDetailSampel(final int coba, final Baris baris, final boolean sudahUlang) {
        if (detailSiap()) {
            // beri jeda biar halaman detail benar-benar jadi sebelum dibaca
            h.postDelayed(new Runnable() { @Override public void run() { bacaDetailSampel(0); } }, 1100);
            return;
        }
        if (!namaDiDaftar && coba == 4 && !sudahUlang) {
            tulis("   … ketuk ulang baris");
            ketukBaris(baris.node);
            h.postDelayed(new Runnable() { @Override public void run() { tungguDetailSampel(coba + 1, baris, true); } }, 1500);
            return;
        }
        if (coba >= 10) {
            tulis("   ⚠ gagal buka detail, dilewati");
            hasilSampel.add("(gagal buka detail)");
            performGlobalAction(GLOBAL_ACTION_BACK);
            h.postDelayed(new Runnable() { @Override public void run() { tungguDaftarLagi(0); } }, 1500);
            return;
        }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDetailSampel(coba + 1, baris, sudahUlang); } }, 1000);
    }

    private String[] detailPertama;

    /** Nama pengirim dari baris daftar (lebih andal daripada dari detail). */
    private String namaDariBaris(String row) {
        if (row == null) return "";
        String low = row.toLowerCase(Locale.ROOT);
        if (low.startsWith("transfer dari") || low.startsWith("diterima dari")) {
            String nm = row.substring(13).trim();
            int rp = nm.indexOf("Rp");
            if (rp > 0) nm = nm.substring(0, rp).trim();
            return nm;
        }
        return "";
    }

    private static final int MAX_ULANG = 4;   // berapa kali coba sampai nama & jam lengkap

    /** Kumpulkan data detail terbaik sejauh ini (gabung bacaan lama + baru + nama dari daftar). */
    private String[] ambilDetailTerbaik() {
        String[] d = dataDetail();
        if (detailPertama != null) for (int i = 0; i < 5; i++) if (d[i].isEmpty()) d[i] = detailPertama[i];
        if (namaDiDaftar && barisAktif != null) {
            String nmBaris = namaDariBaris(barisAktif.key);
            if (!nmBaris.isEmpty()) d[0] = nmBaris;   // nama dari daftar paling andal
        }
        detailPertama = d;
        return d;
    }

    /**
     * Baca detail. ATURAN: kalau NAMA atau JAM belum terbaca, JANGAN lanjut —
     * ulangi (buka ⌄ / gulir, tunggu) sampai lengkap, maksimal MAX_ULANG kali.
     * Kalau sampai batas tetap tidak lengkap → tandai ⛔ (di fitur asli: TIDAK release).
     */
    private void bacaDetailSampel(final int ulang) {
        String[] d = ambilDetailTerbaik();
        boolean lengkap = !d[0].isEmpty() && !d[3].isEmpty();   // nama & jam wajib ada

        if (!lengkap && ulang < MAX_ULANG) {
            tulis("   … nama/jam belum lengkap (percobaan " + (ulang + 1) + "/" + MAX_ULANG + ") — ulangi, belum lanjut");
            if (ovo) {
                AccessibilityNodeInfo dt = cariTeksMengandung(new String[]{"detail transaksi"});
                if (dt != null) {
                    Rect b = new Rect(); dt.getBoundsInScreen(b);
                    int x = (int) (getResources().getDisplayMetrics().widthPixels * 0.90f);  // tanda ⌄ ujung kanan
                    ketuk(x, b.centerY());
                } else { geser(true); }
            } else {
                geser(true);
            }
            tungguLengkap(0, ulang + 1);   // tunggu sampai nama & jam muncul, baru coba lagi
            return;
        }

        String garis;
        if (lengkap) {
            garis = d[0] + " · " + (d[1].isEmpty() ? "—" : d[1]) + " · " + d[3] + " · " + tandaStatus(d[4]);
            tulis("   ✓ " + garis);
        } else {
            garis = "⛔ BELUM LENGKAP → " + (d[0].isEmpty() ? "(nama?)" : d[0])
                    + " · " + (d[1].isEmpty() ? "—" : d[1]) + " · " + (d[3].isEmpty() ? "jam?" : d[3]);
            tulis("   ⛔ nama/jam tak terbaca penuh setelah " + MAX_ULANG + "x — di fitur asli: TIDAK release (manual)");
        }
        hasilSampel.add(garis);
        performGlobalAction(GLOBAL_ACTION_BACK);
        h.postDelayed(new Runnable() { @Override public void run() { tungguDaftarLagi(0); } }, 1500);
    }

    /** Tunggu SAMPAI nama & jam muncul (cek tiap 0,7 dtk), baru coba baca lagi — tahan HP lemot. */
    private void tungguLengkap(final int coba, final int ulangBerikut) {
        String[] d = ambilDetailTerbaik();
        boolean lengkap = !d[0].isEmpty() && !d[3].isEmpty();
        if (lengkap || coba >= 8) { bacaDetailSampel(ulangBerikut); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguLengkap(coba + 1, ulangBerikut); } }, 700);
    }

    private void tungguDaftarLagi(final int coba) {
        if (daftarSiap() || coba >= 8) { h.postDelayed(new Runnable() { @Override public void run() { langkahKoleksi(); } }, 600); return; }
        h.postDelayed(new Runnable() { @Override public void run() { tungguDaftarLagi(coba + 1); } }, 1000);
    }

    private void selesaiKoleksi(String alasan) {
        StringBuilder sb = new StringBuilder("📊 HASIL " + hasilSampel.size() + " SAMPEL (dari detail) — " + alasan + "\n");
        int no = 1;
        for (String s : hasilSampel) sb.append("  ").append(no++).append(". ").append(s).append("\n");
        tulis(sb.toString());
        kembali();
    }

    /** Baris transaksi MASUK yang terlihat di layar (untuk koleksi banyak sampel). */
    private List<Baris> kumpulBaris() {
        int tinggi = getResources().getDisplayMetrics().heightPixels;
        List<Baris> out = new ArrayList<>();
        java.util.HashSet<String> dipakai = new java.util.HashSet<>();
        List<AccessibilityNodeInfo> nodes = semuaNode();
        for (AccessibilityNodeInfo n : nodes) {
            String t = teksNode(n); String low = t.toLowerCase(Locale.ROOT);
            if (!teksMasuk(low)) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            if (b.height() <= 0 || b.centerY() < tinggi * 0.12 || b.centerY() > tinggi * 0.92) continue;
            String key, label;
            if (namaDiDaftar) {
                key = t;                                   // teks baris (nama) sudah cukup unik
                label = ringkasTeks(t);
            } else {
                String jam = jamDekat(nodes, b.centerY()); // jam baris DANA sbg kunci
                key = jam != null ? jam : ("y" + b.centerY());
                label = "(masuk) " + (jam != null ? jam : ("baris@" + b.centerY()));
            }
            if (dipakai.contains(key)) continue;
            dipakai.add(key);
            out.add(new Baris(key, label, b.centerY(), n));
        }
        java.util.Collections.sort(out, new java.util.Comparator<Baris>() {
            @Override public int compare(Baris a, Baris b) { return Integer.compare(a.tapY, b.tapY); }
        });
        return out;
    }

    /** Jam baris DANA = teks jam TERDEKAT yang berada DI BAWAH label "Receive Money"/"Terima Uang". */
    private String jamDekat(List<AccessibilityNodeInfo> nodes, int y) {
        String jam = null; int jarak = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : nodes) {
            String t = teksNode(n);
            if (t.length() >= 40) continue;
            Matcher m = P_JAM.matcher(t);
            if (!m.find()) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            int dy = b.centerY() - y;
            if (dy < 0 || dy > 200) continue;        // hanya yang di bawah label, dalam 200px
            if (dy < jarak) { jarak = dy; jam = m.group().replace('.', ':'); }
        }
        return jam;
    }

    // ───────────────────────── RINGKAS (hasil rapi) ─────────────────────────

    /** Daftar transaksi, versi rapi: nama · nominal · jam (satu baris per transaksi). */
    private void ringkas(String judul) {
        List<String> baris = teksUrut();
        List<String> out = ovo ? ringkasOVO(baris) : goPay ? ringkasGoPay(baris) : ringkasDana(baris);
        StringBuilder sb = new StringBuilder("📋 " + judul + "\n");
        if (out.isEmpty()) {
            sb.append("  (tidak ada transaksi terbaca)\n");
            int c = 0;
            for (String t : baris) if (P_NOMINAL.matcher(t).find() && c++ < 12) sb.append("  · ").append(ringkasTeks(t)).append("\n");
        } else {
            int no = 1;
            for (String s : out) { sb.append("  ").append(no++).append(". ").append(s).append("\n"); if (no > 15) break; }
            sb.append("  (").append(out.size()).append(" transaksi)");
        }
        tulis(sb.toString());
    }

    /** Baca data detail → {nama, nominal, tanggal, jam, status}. status = "GAGAL" / "OK" / "". */
    private String[] dataDetail() {
        List<String> baris = teksUrut();
        String nmn = "", jam = "", tgl = "", nm = "", status = "";
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            // status transaksi — PENTING: transaksi GAGAL tetap muncul di riwayat
            if (status.isEmpty()) {
                if (low.contains("gagal") || low.contains("dibatalkan") || low.contains("failed") || low.contains("cancel"))
                    status = "GAGAL";
                else if (low.contains("berhasil") || low.contains("selesai") || low.contains("success") || low.contains("completed"))
                    status = "OK";
            }
            int d = low.indexOf(" dari "); if (d < 0) d = low.indexOf(" from ");
            if (d >= 0 && (low.contains("terima") || low.contains("receive"))) {
                nm = t.substring(d + 6).trim();
                Matcher m = P_NOMINAL.matcher(t); if (m.find()) nmn = rapiRp(m.group());
            }
            if (low.startsWith("diterima dari")) nm = t.substring(13).trim();
            if (low.startsWith("transfer dari")) nm = t.substring(13).trim();   // OVO
            if (nmn.isEmpty()) { Matcher m = P_NOMINAL.matcher(t); if (m.find() && t.length() < 40) nmn = rapiRp(m.group()); }
            if (jam.isEmpty()) { Matcher m = P_JAM.matcher(t); if (m.find() && t.length() < 40) jam = m.group().replace('.', ':'); }
            if (tgl.isEmpty()) { Matcher m = P_TGL.matcher(t); if (m.find()) tgl = m.group(); }
        }
        return new String[]{nm, nmn, tgl, jam, status};
    }

    private String tandaStatus(String status) {
        if ("GAGAL".equals(status)) return "❌ GAGAL";
        if ("OK".equals(status)) return "✅";
        return "status?";
    }

    private void ringkasDetail(String judul) {
        String[] d = dataDetail();
        StringBuilder sb = new StringBuilder("🔎 " + judul + "\n");
        sb.append("  Status : ").append(tandaStatus(d[4])).append("\n");
        sb.append("  Nama   : ").append(d[0].isEmpty() ? "— (tidak terbaca)" : d[0]).append("\n");
        sb.append("  Nominal: ").append(d[1].isEmpty() ? "—" : d[1]).append("\n");
        sb.append("  Tanggal: ").append(d[2].isEmpty() ? "—" : d[2]).append("\n");
        sb.append("  Jam    : ").append(d[3].isEmpty() ? "— (tidak terbaca)" : d[3]);
        tulis(sb.toString());
    }

    /** OVO: baris "Transfer Dari NAMA", nominal "+Rp..." di node berikutnya. */
    private List<String> ringkasOVO(List<String> baris) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < baris.size(); i++) {
            String t = baris.get(i);
            if (!t.toLowerCase(Locale.ROOT).startsWith("transfer dari")) continue; // hanya MASUK
            String nm = t.substring(13).trim();
            String rp = "—";
            for (int j = i + 1; j < baris.size() && j <= i + 3; j++) {   // cari nominal di baris dekat
                Matcher m = P_NOMINAL.matcher(baris.get(j));
                if (m.find()) { rp = rapiRp(m.group()); break; }
            }
            out.add(nm + " · " + rp);
        }
        return out;
    }

    private List<String> ringkasGoPay(List<String> baris) {
        List<String> out = new ArrayList<>();
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            if (!low.startsWith("diterima dari")) continue; // hanya uang MASUK
            Matcher m = P_NOMINAL.matcher(t);
            String rp = m.find() ? rapiRp(m.group()) : "—";
            String nm = t.substring(13).trim();
            int rpos = nm.indexOf("Rp");
            if (rpos > 0) nm = nm.substring(0, rpos).trim();
            out.add(nm + " · " + rp);
        }
        return out;
    }

    private List<String> ringkasDana(List<String> baris) {
        List<String> out = new ArrayList<>();
        String nm = null, jam = null, rp = null;
        for (String t : baris) {
            String low = t.toLowerCase(Locale.ROOT);
            boolean anchor = low.startsWith("terima uang") || low.startsWith("kirim ke") || low.startsWith("terima transfer")
                    || low.startsWith("receive money") || low.startsWith("send to") || low.startsWith("received transfer");
            if (anchor) {
                if (nm != null) out.add(gabung(nm, rp, jam));
                nm = (low.startsWith("terima uang") || low.startsWith("receive money")) ? "(masuk)" : t;
                jam = null; rp = null;
                Matcher m = P_NOMINAL.matcher(t); if (m.find()) rp = rapiRp(m.group());
                int d = low.indexOf(" dari "); if (d < 0) d = low.indexOf(" from ");
                if (d >= 0) nm = "dari " + t.substring(d + 6).trim();
                continue;
            }
            if (nm == null) continue;
            Matcher mj = P_JAM.matcher(t); if (jam == null && mj.find() && t.length() < 40) jam = mj.group().replace('.', ':');
            Matcher mr = P_NOMINAL.matcher(t); if (rp == null && mr.find() && t.length() < 25) rp = rapiRp(mr.group());
        }
        if (nm != null) out.add(gabung(nm, rp, jam));
        return out;
    }

    private String gabung(String nm, String rp, String jam) {
        String s = nm + " · " + (rp == null ? "—" : rp);
        if (jam != null) s += " · " + jam;
        return s;
    }

    private String rapiRp(String s) { return s.replace(" ", ""); }
    private String ringkasTeks(String s) { return s.length() > 70 ? s.substring(0, 70) + "…" : s; }

    // ───────────────────────── membaca & mencari ─────────────────────────

    /** Semua teks yang terlihat di jendela aplikasi target, urut dari atas ke bawah. */
    private List<String> teksUrut() {
        final List<Long> yPos = new ArrayList<>();
        final List<String> teks = new ArrayList<>();
        List<AccessibilityWindowInfo> jendela = null;
        try { jendela = getWindows(); } catch (Exception ignored) { }
        boolean ada = false;
        if (jendela != null) {
            for (AccessibilityWindowInfo w : jendela) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                String pk = root.getPackageName() == null ? "" : root.getPackageName().toString();
                if (pk.equals(getPackageName()) || pk.equals("com.android.systemui")) continue;
                ada = true;
                kumpulTeks(root, 0, teks, yPos);
            }
        }
        if (!ada) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) kumpulTeks(root, 0, teks, yPos);
        }
        Integer[] urut = new Integer[teks.size()];
        for (int i = 0; i < urut.length; i++) urut[i] = i;
        java.util.Arrays.sort(urut, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer a, Integer b) { return Long.compare(yPos.get(a), yPos.get(b)); }
        });
        List<String> hasil = new ArrayList<>();
        String sebelum = null;
        for (int i : urut) {
            String t = teks.get(i);
            if (t.equals(sebelum)) continue;
            hasil.add(t);
            sebelum = t;
        }
        return hasil;
    }

    private void kumpulTeks(AccessibilityNodeInfo n, int dk, List<String> teks, List<Long> yPos) {
        if (n == null || dk > 60) return;
        String t = teksNode(n);
        if (t.length() > 0) {
            Rect b = new Rect(); n.getBoundsInScreen(b);
            teks.add(t);
            yPos.add((long) b.top * 10000 + b.left);
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = null; try { c = n.getChild(i); } catch (Exception ignored) { }
            kumpulTeks(c, dk + 1, teks, yPos);
        }
    }

    private void kumpulkan(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int dk) {
        if (n == null || dk > 60) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = null; try { c = n.getChild(i); } catch (Exception ignored) { }
            kumpulkan(c, out, dk + 1);
        }
    }

    private List<AccessibilityNodeInfo> semuaNode() {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        kumpulkan(getRootInActiveWindow(), out, 0);
        return out;
    }

    private static String teksNode(AccessibilityNodeInfo n) {
        String t = n.getText() == null ? "" : n.getText().toString().trim();
        if (t.length() == 0 && n.getContentDescription() != null) t = n.getContentDescription().toString().trim();
        return t.replace('\n', ' ');
    }

    private AccessibilityNodeInfo cariTeks(String[] kata) {
        List<AccessibilityNodeInfo> semua = semuaNode();
        for (String k : kata)
            for (AccessibilityNodeInfo n : semua)
                if (teksNode(n).toLowerCase(Locale.ROOT).equals(k)) return n;
        for (String k : kata)
            for (AccessibilityNodeInfo n : semua) {
                String t = teksNode(n).toLowerCase(Locale.ROOT);
                if (t.length() > 0 && t.length() < 30 && t.contains(k)) return n;
            }
        return null;
    }

    private AccessibilityNodeInfo cariTeksMengandung(String[] kata) {
        for (AccessibilityNodeInfo n : semuaNode()) {
            String t = teksNode(n).toLowerCase(Locale.ROOT);
            for (String k : kata) if (t.contains(k)) return n;
        }
        return null;
    }

    /** Baris transaksi MASUK teratas yang terlihat: GoPay "Diterima dari…", DANA "Terima Uang". */
    private AccessibilityNodeInfo cariBarisMasuk() {
        int tinggi = getResources().getDisplayMetrics().heightPixels;
        AccessibilityNodeInfo terbaik = null; int yBaik = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : semuaNode()) {
            String low = teksNode(n).toLowerCase(Locale.ROOT);
            if (!teksMasuk(low)) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            if (b.height() <= 0 || b.centerY() < tinggi * 0.15 || b.centerY() > tinggi * 0.85) continue;
            if (b.centerY() < yBaik) { yBaik = b.centerY(); terbaik = n; }
        }
        return terbaik;
    }

    private String klik(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n; int naik = 0;
        while (x != null && !x.isClickable() && naik < 8) { x = x.getParent(); naik++; }
        if (x != null && x.isClickable() && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "klik";
        Rect b = new Rect(); n.getBoundsInScreen(b);
        ketuk(b.centerX(), b.centerY());
        return "ketuk " + b.centerX() + "," + b.centerY();
    }

    private void ketuk(int x, int y) {
        Path p = new Path(); p.moveTo(x, y);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null);
    }

    /** Gulir daftar. maju = turun. */
    private String geser(boolean maju) {
        AccessibilityNodeInfo besar = null; int luas = 0;
        for (AccessibilityNodeInfo n : semuaNode()) {
            if (!n.isScrollable()) continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            int l = b.width() * b.height();
            if (l > luas) { luas = l; besar = n; }
        }
        if (besar != null && besar.performAction(maju
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
            return "gulir";
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int x = dm.widthPixels / 2, atas = (int) (dm.heightPixels * 0.30f), bawah = (int) (dm.heightPixels * 0.75f);
        Path p = new Path();
        if (maju) { p.moveTo(x, bawah); p.lineTo(x, atas); } else { p.moveTo(x, atas); p.lineTo(x, bawah); }
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 450)).build(), null, null);
        return "usap";
    }

    /** Tarik ke bawah dari atas layar (pull-to-refresh). */
    private void refreshGulir() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int x = dm.widthPixels / 2, atas = (int) (dm.heightPixels * 0.30f), bawah = (int) (dm.heightPixels * 0.80f);
        Path p = new Path(); p.moveTo(x, atas); p.lineTo(x, bawah);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 500)).build(), null, null);
    }

    // ───────────────────────── tombol 📸 manual ─────────────────────────

    boolean tombolTampil() { return tombol != null; }

    void tampilkanTombol() {
        if (tombol != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        final float dp = getResources().getDisplayMetrics().density;
        int ukuran = (int) (58 * dp);
        tombol = new TextView(this);
        tombol.setText("📸"); tombol.setTextSize(26); tombol.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL); bg.setColor(0xFFF0B90B); bg.setStroke((int) (2 * dp), 0xFF000000);
        tombol.setBackground(bg);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ukuran, ukuran,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL; lp.x = (int) (12 * dp);
        tombol.setOnTouchListener(new View.OnTouchListener() {
            float awalY; int awalLpY; boolean jauh;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: awalY = e.getRawY(); awalLpY = lp.y; jauh = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dy = e.getRawY() - awalY;
                        if (Math.abs(dy) > 12 * dp) jauh = true;
                        if (jauh) { lp.y = awalLpY + (int) dy; try { wm.updateViewLayout(tombol, lp); } catch (Exception ignored) { } }
                        return true;
                    case MotionEvent.ACTION_UP: if (!jauh) bacaManual(); return true;
                }
                return false;
            }
        });
        try { wm.addView(tombol, lp); tulis("📸 Tombol baca manual tampil (geser untuk memindah)"); }
        catch (Exception e) { tombol = null; tulis("✗ Tombol melayang gagal: " + e.getMessage()); }
    }

    void sembunyikanTombol() {
        if (tombol != null && wm != null) { try { wm.removeView(tombol); } catch (Exception ignored) { } }
        tombol = null;
    }

    private void bacaManual() {
        manualKe++;
        String pk = paketAktif();
        goPay = pk.contains("gopay");
        List<String> baris = teksUrut();
        boolean detail = false;
        for (String t : baris) { String l = t.toLowerCase(Locale.ROOT);
            if (l.contains("rincian transaksi") || l.startsWith("terima transfer") || l.startsWith("detail transaksi")) { detail = true; break; } }
        if (detail) ringkasDetail("DETAIL (manual)"); else ringkas("📸 MANUAL #" + manualKe + " (" + pk + ")");
        Toast.makeText(this, "📸 #" + manualKe, Toast.LENGTH_SHORT).show();
    }
}